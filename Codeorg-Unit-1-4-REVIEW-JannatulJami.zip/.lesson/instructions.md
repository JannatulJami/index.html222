# Instructions  

  ** Use the Index.html page to review concepts from Code.org Unit 3 Intro to App Design**

  _ Create a page for hosting your Project_

  ## Steps
  1. Answer all Check for understanding on the Index
  2. Use HTML tags to organize your content
  3. Link the index to your project page
  4. Use Selectors as per class instruction to prep for CSS
  5. Embed the app you design with your partner on a separate page.
  6.  [ Project overview](ProjectDescription.png)
  7.  Survey your Peers  [ Audit](targetAudit.png)
  8.  Plan your App  [ Flowchart](flowchart.png)
  9.  Design  [ Design](DEsign.png)
  10.  Reflect  [ Improvements](REflect.png)
  11. App Design  [ Rubric](Rubric.png)
 

  

  